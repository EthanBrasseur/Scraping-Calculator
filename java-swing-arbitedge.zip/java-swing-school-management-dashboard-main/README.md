# java-swing-school-management-dashboard
Date : 05/10/2021<br/>
How to coding in java
visit my youtube : https://www.youtube.com/c/HelloWorld-Raven/featured
<br/><br/>

![2021-10-05_103049](https://user-images.githubusercontent.com/58245926/135955869-a4be26f1-e28d-4362-b4f4-67ba1f8e2328.png)

![2021-10-05_103119](https://user-images.githubusercontent.com/58245926/135955871-d522c65f-aed3-4ba6-9a4f-2d844a16c43a.png)

- Version 2

![2021-10-18_210420](https://user-images.githubusercontent.com/58245926/137754866-ae8ff45b-6585-4abc-9164-eb908a0892bd.png)
